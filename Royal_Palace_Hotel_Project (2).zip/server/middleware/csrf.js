/**
 * CSRF protection — synchronizer token pattern tied to the session.
 *
 * Why not the `csurf` npm package: it's been deprecated/unmaintained since
 * 2022 and has known issues. This is a small, self-contained implementation
 * of the same well-established pattern instead of pulling in an unmaintained
 * dependency.
 *
 * Flow:
 *   1. GET /api/auth/csrf-token generates a token, stores it in the session,
 *      and returns it to the frontend.
 *   2. The frontend includes it as an `X-CSRF-Token` header on every
 *      state-changing request (POST/PATCH/DELETE).
 *   3. This middleware compares the header value to the session value using
 *      a timing-safe comparison.
 */

const crypto = require('crypto');

function generateCsrfToken(req, res) {
  const token = crypto.randomBytes(32).toString('hex');
  req.session.csrfToken = token;
  res.json({ success: true, csrfToken: token });
}

function requireCsrfToken(req, res, next) {
  const headerToken = req.headers['x-csrf-token'];
  const sessionToken = req.session && req.session.csrfToken;

  if (!headerToken || !sessionToken) {
    return res.status(403).json({ success: false, error: 'Missing CSRF token.' });
  }

  const a = Buffer.from(String(headerToken));
  const b = Buffer.from(String(sessionToken));
  const valid = a.length === b.length && crypto.timingSafeEqual(a, b);

  if (!valid) {
    return res.status(403).json({ success: false, error: 'Invalid CSRF token.' });
  }
  next();
}

module.exports = { generateCsrfToken, requireCsrfToken };
