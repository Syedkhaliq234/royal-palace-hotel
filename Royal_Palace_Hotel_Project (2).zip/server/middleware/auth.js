/**
 * Session-based auth middleware. Requires express-session to already be
 * configured in app.js (with a real store — connect-pg-simple — not the
 * default MemoryStore, which leaks memory and doesn't work with more than
 * one server process).
 */

function requireAuth(req, res, next) {
  if (!req.session || !req.session.userId) {
    return res.status(401).json({ success: false, error: 'Not authenticated.' });
  }
  next();
}

/**
 * @param {...string} allowedRoles - e.g. requireRole('admin', 'manager')
 */
function requireRole(...allowedRoles) {
  return (req, res, next) => {
    if (!req.session || !req.session.userId) {
      return res.status(401).json({ success: false, error: 'Not authenticated.' });
    }
    if (!allowedRoles.includes(req.session.role)) {
      return res.status(403).json({ success: false, error: 'You do not have permission to perform this action.' });
    }
    next();
  };
}

module.exports = { requireAuth, requireRole };
