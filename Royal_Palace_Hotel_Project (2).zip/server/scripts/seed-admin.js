/**
 * Creates (or updates) the first admin account, using SEED_ADMIN_* values
 * from .env. Run once after the schema is loaded:
 *
 *   npm run seed:admin
 *
 * Safe to re-run — it upserts by email.
 */
require('dotenv').config();
const bcrypt = require('bcrypt');
const { pool } = require('../db');

async function main() {
  const name = process.env.SEED_ADMIN_NAME;
  const email = (process.env.SEED_ADMIN_EMAIL || '').trim().toLowerCase();
  const password = process.env.SEED_ADMIN_PASSWORD;

  if (!name || !email || !password) {
    console.error('SEED_ADMIN_NAME, SEED_ADMIN_EMAIL, and SEED_ADMIN_PASSWORD must all be set in .env.');
    process.exit(1);
  }
  if (password.length < 12) {
    console.error('SEED_ADMIN_PASSWORD should be at least 12 characters. Choose a stronger password.');
    process.exit(1);
  }

  const passwordHash = await bcrypt.hash(password, 12);

  await pool.query(
    `INSERT INTO users (name, email, password_hash, role)
     VALUES ($1, $2, $3, 'admin')
     ON CONFLICT (email) DO UPDATE SET name = EXCLUDED.name, password_hash = EXCLUDED.password_hash`,
    [name, email, passwordHash]
  );

  console.log(`Admin account ready: ${email}`);
  console.log('You can now log in via POST /api/auth/login with this email and the password from .env.');
  console.log('Consider removing SEED_ADMIN_PASSWORD from .env after this runs, since it is no longer needed.');

  await pool.end();
}

main().catch((err) => {
  console.error('Seed failed:', err);
  process.exit(1);
});
