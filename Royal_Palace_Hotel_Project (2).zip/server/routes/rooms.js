const express = require('express');
const { query } = require('../db');
const { requireRole } = require('../middleware/auth');
const { requireCsrfToken } = require('../middleware/csrf');

const router = express.Router();

// Public: list active rooms (for the website to render room cards from
// real data instead of hard-coded HTML, if/when the frontend is wired to
// call this — see README "Connecting the frontend" section).
router.get('/rooms', async (req, res) => {
  try {
    const result = await query(
      `SELECT id, room_type, name, description, price_cents, currency, capacity, amenities, images
       FROM rooms WHERE status = 'active' ORDER BY price_cents ASC`
    );
    res.json({ success: true, rooms: result.rows });
  } catch (err) {
    console.error('List rooms error:', err);
    res.status(500).json({ success: false, error: 'Could not retrieve rooms.' });
  }
});

router.post('/rooms', requireRole('admin', 'manager'), requireCsrfToken, async (req, res) => {
  const b = req.body || {};
  if (!b.room_type || !b.name || !Number.isInteger(b.price_cents) || b.price_cents < 0) {
    return res.status(400).json({ success: false, error: 'room_type, name, and a valid price_cents are required.' });
  }
  try {
    const result = await query(
      `INSERT INTO rooms (room_type, name, description, price_cents, currency, capacity, total_units, amenities, images)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9) RETURNING id`,
      [
        b.room_type,
        b.name,
        b.description || '',
        b.price_cents,
        b.currency || 'USD',
        b.capacity || 2,
        b.total_units || 1,
        JSON.stringify(b.amenities || []),
        JSON.stringify(b.images || []),
      ]
    );
    res.status(201).json({ success: true, id: result.rows[0].id });
  } catch (err) {
    console.error('Create room error:', err);
    res.status(500).json({ success: false, error: 'Could not create room.' });
  }
});

router.patch('/rooms/:id', requireRole('admin', 'manager'), requireCsrfToken, async (req, res) => {
  const allowedFields = ['name', 'description', 'price_cents', 'currency', 'capacity', 'total_units', 'status'];
  const b = req.body || {};
  const setClauses = [];
  const params = [];

  for (const field of allowedFields) {
    if (b[field] !== undefined) {
      params.push(b[field]);
      setClauses.push(`${field} = $${params.length}`);
    }
  }
  if (b.amenities !== undefined) {
    params.push(JSON.stringify(b.amenities));
    setClauses.push(`amenities = $${params.length}`);
  }
  if (b.images !== undefined) {
    params.push(JSON.stringify(b.images));
    setClauses.push(`images = $${params.length}`);
  }
  if (setClauses.length === 0) {
    return res.status(400).json({ success: false, error: 'No valid fields to update.' });
  }

  params.push(req.params.id);
  try {
    const result = await query(`UPDATE rooms SET ${setClauses.join(', ')} WHERE id = $${params.length} RETURNING id`, params);
    if (result.rows.length === 0) return res.status(404).json({ success: false, error: 'Room not found.' });
    res.json({ success: true });
  } catch (err) {
    console.error('Update room error:', err);
    res.status(500).json({ success: false, error: 'Could not update room.' });
  }
});

router.delete('/rooms/:id', requireRole('admin'), requireCsrfToken, async (req, res) => {
  try {
    // Soft-delete: rooms with existing bookings can't be hard-deleted
    // without violating the foreign key, which is intentional — booking
    // history must never silently disappear.
    const result = await query(`UPDATE rooms SET status = 'inactive' WHERE id = $1 RETURNING id`, [req.params.id]);
    if (result.rows.length === 0) return res.status(404).json({ success: false, error: 'Room not found.' });
    res.json({ success: true });
  } catch (err) {
    console.error('Delete room error:', err);
    res.status(500).json({ success: false, error: 'Could not delete room.' });
  }
});

module.exports = router;
