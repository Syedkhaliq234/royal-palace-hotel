/**
 * Payment architecture — Stripe (PaymentIntents API).
 *
 * HONESTY NOTE: This code is real and complete (not commented-out
 * scaffolding), but it has NOT been exercised against a live Stripe
 * account or even a live server in this environment — no network access,
 * no credentials, and `npm install` itself could not complete here (see
 * README "What has NOT been tested"). It follows Stripe's documented
 * PaymentIntents + webhook pattern as of this writing; verify against
 * Stripe's current docs and test with sandbox/test-mode keys before
 * going live.
 *
 * The `stripe` package is only require()'d lazily, inside the functions
 * below, and only once STRIPE_SECRET_KEY is actually set — so this file
 * loads and passes `node --check` even before `npm install stripe` has
 * been run (it's listed under optionalDependencies in package.json for
 * exactly this reason).
 */

const express = require('express');
const rateLimit = require('express-rate-limit');
const { query, withTransaction } = require('../db');
const { requireCsrfToken } = require('../middleware/csrf');
const { verifyPaymentToken } = require('../lib/tokens');

const router = express.Router();

const STRIPE_SECRET_KEY = process.env.STRIPE_SECRET_KEY;
const STRIPE_WEBHOOK_SECRET = process.env.STRIPE_WEBHOOK_SECRET;

// There is no guest-account/login system in this project (see README) —
// a guest never authenticates with a username/password. Still rate-limited
// as defense-in-depth even though the token below is not brute-forceable
// in any practical sense (256 bits of entropy).
const paymentCreateLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, error: 'Too many attempts. Please try again later.' },
});

let stripeClient = null;
function getStripeClient() {
  if (!STRIPE_SECRET_KEY) return null;
  if (!stripeClient) {
    stripeClient = require('stripe')(STRIPE_SECRET_KEY);
  }
  return stripeClient;
}

function paymentNotConfigured(res) {
  return res.status(501).json({
    success: false,
    error: 'STRIPE_CONFIGURATION_REQUIRED',
    detail: 'STRIPE_SECRET_KEY is not set. Add real Stripe credentials to .env, then run npm install (stripe is an optional dependency) before payments can be processed.',
  });
}

// PaymentIntent statuses that mean "still usable, safe to hand the same
// clientSecret back to the frontend" — anything else (canceled, or
// already succeeded, handled separately above) means we should not reuse it.
const REUSABLE_INTENT_STATUSES = ['requires_payment_method', 'requires_confirmation', 'requires_action', 'processing'];

/**
 * POST /api/payments/create
 * Creates a Stripe PaymentIntent for an existing booking and records a
 * `pending` row in the payments table. The frontend uses the returned
 * clientSecret with Stripe.js to collect card details — actual card
 * capture never touches this server, only Stripe's own hosted fields.
 *
 * Body: { booking_reference, payment_token }
 *
 * AUTHORIZATION MECHANISM (server-generated capability token, not
 * booking_id and not a guessable/knowable value like email):
 *
 * This is a public, unauthenticated hotel-booking flow — there are no
 * guest accounts to log into, so classic "is this the logged-in owner of
 * this resource" authorization doesn't apply. Instead: at booking
 * creation (POST /api/bookings), the server generates a 256-bit random
 * `payment_token`, stores only its SHA-256 hash in the database, and
 * returns the raw token to the client EXACTLY ONCE, in that response.
 * Nothing else — not booking_id, not booking_reference, not email — is
 * ever accepted as proof of ownership here. booking_reference alone is
 * NOT a secret (it's shown in confirmation emails/screens and is only
 * ~30 bits of entropy); payment_token is the actual authorization
 * control, and is high-entropy, single-purpose, and never logged.
 * Guessing or brute-forcing a valid token is not practically feasible.
 *
 * DUPLICATE-PAYMENT PREVENTION (three independent layers):
 *
 * 1. Database row lock: the booking row is SELECTed FOR UPDATE inside a
 *    transaction, so two near-simultaneous requests for the same booking
 *    (double-click, network retry) are serialized — the second one waits
 *    for the first to finish before it can even check for an existing
 *    payment. This transaction stays open for the duration of the Stripe
 *    API call(s) below, which is a deliberate trade-off: it holds a
 *    Postgres lock a little longer than ideal (network round-trip to
 *    Stripe) in exchange for a correctness guarantee that matters more
 *    here than raw throughput at this scale (a single hotel's booking
 *    volume, not a high-frequency system).
 * 2. Existing-payment reuse: before creating anything new, we check for
 *    an existing 'pending' payment row for this booking and, if found,
 *    verify its real status directly with Stripe (our DB row alone isn't
 *    proof it's still usable) and hand back the same clientSecret rather
 *    than creating a second PaymentIntent.
 * 3. Stripe idempotency key: even if something slipped past both of the
 *    above (this route being called from two different server processes
 *    without a shared lock, for example, in some future deployment
 *    topology), the idempotency key passed to Stripe is deterministic
 *    per booking, so Stripe itself will return the original PaymentIntent
 *    for a retried request with the same key instead of creating a new one.
 */
router.post('/payments/create', paymentCreateLimiter, requireCsrfToken, async (req, res) => {
  const stripe = getStripeClient();
  if (!stripe) return paymentNotConfigured(res);

  const bookingReference = (req.body && req.body.booking_reference || '').trim();
  const paymentToken = (req.body && req.body.payment_token || '').trim();

  if (!bookingReference || !paymentToken) {
    return res.status(400).json({ success: false, error: 'booking_reference and payment_token are required.' });
  }

  try {
    const result = await withTransaction(async (client) => {
      const bookingResult = await client.query(
        `SELECT id, total_amount_cents, currency, payment_status, payment_token_hash
         FROM bookings WHERE booking_reference = $1 FOR UPDATE`,
        [bookingReference]
      );
      const booking = bookingResult.rows[0];

      // Generic 404 whether the reference doesn't exist OR the token is
      // wrong — never reveal which one failed, so this can't be used to
      // enumerate valid references.
      if (!booking || !verifyPaymentToken(paymentToken, booking.payment_token_hash)) {
        const err = new Error('Booking not found.');
        err.statusCode = 404;
        throw err;
      }
      if (booking.payment_status === 'paid') {
        const err = new Error('This booking has already been paid.');
        err.statusCode = 409;
        throw err;
      }

      // Look for an existing payment attempt for this booking before
      // creating a new one.
      const existingResult = await client.query(
        `SELECT id, provider_payment_id, status FROM payments
         WHERE booking_id = $1 AND provider = 'stripe'
         ORDER BY created_at DESC LIMIT 1`,
        [booking.id]
      );
      const existing = existingResult.rows[0];

      if (existing && existing.status === 'pending' && existing.provider_payment_id) {
        // The DB says pending, but Stripe is the source of truth for
        // whether it's actually still safe to reuse (it could have
        // succeeded via a webhook we haven't processed in this instant,
        // or expired/been canceled on Stripe's side).
        const remoteIntent = await stripe.paymentIntents.retrieve(existing.provider_payment_id);

        if (remoteIntent.status === 'succeeded') {
          const err = new Error('This booking has already been paid.');
          err.statusCode = 409;
          throw err;
        }
        if (REUSABLE_INTENT_STATUSES.includes(remoteIntent.status)) {
          return { clientSecret: remoteIntent.client_secret };
        }
        // Any other status (e.g. canceled) — fall through and create a
        // fresh PaymentIntent below instead of reusing a dead one.
      }

      const paymentIntent = await stripe.paymentIntents.create(
        {
          amount: booking.total_amount_cents,
          currency: booking.currency.toLowerCase(),
          metadata: { booking_id: booking.id },
        },
        {
          // Deterministic per booking: a retried request with identical
          // parameters returns Stripe's original PaymentIntent instead of
          // creating a second one, even outside the DB-lock scenario above.
          idempotencyKey: 'booking-payment-create-' + booking.id,
        }
      );

      await client.query(
        `INSERT INTO payments (booking_id, provider, provider_payment_id, amount_cents, currency, status)
         VALUES ($1, 'stripe', $2, $3, $4, 'pending')
         ON CONFLICT (provider, provider_payment_id) DO NOTHING`,
        [booking.id, paymentIntent.id, booking.total_amount_cents, booking.currency]
      );

      return { clientSecret: paymentIntent.client_secret };
    });

    res.json({ success: true, clientSecret: result.clientSecret });
  } catch (err) {
    const statusCode = err.statusCode || 500;
    if (statusCode === 500) console.error('Payment creation error:', err);
    res.status(statusCode).json({ success: false, error: err.message || 'Could not create payment.' });
  }
});

/**
 * POST /api/payments/webhook
 * Stripe calls this to notify of payment success/failure. The webhook
 * signature is verified server-side using STRIPE_WEBHOOK_SECRET — an
 * unverified request is never trusted, since anyone could otherwise POST
 * a fake "payment succeeded" event directly to this URL.
 *
 * IMPORTANT: this route needs the RAW request body for signature
 * verification. app.js mounts express.raw() for this specific path
 * BEFORE the global express.json() middleware — do not change that
 * ordering, or signature verification will fail even with correct keys.
 *
 * VALIDATION CHAIN before ever marking a booking paid (all must pass):
 *   1. Signature verified (above, before we even look at event contents)
 *   2. A payment record exists for this exact provider_payment_id — an
 *      event for an intent we never created/tracked is ignored, not acted on
 *   3. That payment record isn't already 'succeeded' (webhook idempotency —
 *      Stripe delivers at-least-once, so the same event can arrive twice)
 *   4. The amount on the Stripe event matches what we recorded
 *   5. The currency on the Stripe event matches what we recorded
 *   6. The PaymentIntent's own status is genuinely 'succeeded' (defense in
 *      depth beyond just trusting the event type)
 * Only after all of that does the booking get marked paid/confirmed.
 */
router.post('/payments/webhook', async (req, res) => {
  const stripe = getStripeClient();
  if (!stripe || !STRIPE_WEBHOOK_SECRET) {
    console.warn('[payments] Webhook received but Stripe is not configured — ignoring.');
    return res.status(501).json({ success: false, error: 'STRIPE_CONFIGURATION_REQUIRED' });
  }

  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, req.headers['stripe-signature'], STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error('Webhook signature verification failed:', err.message);
    return res.status(400).json({ success: false, error: 'Invalid signature.' });
  }

  try {
    if (event.type === 'payment_intent.succeeded') {
      const intent = event.data.object;

      const paymentResult = await query(
        `SELECT id, booking_id, amount_cents, currency, status FROM payments
         WHERE provider = 'stripe' AND provider_payment_id = $1`,
        [intent.id]
      );
      const payment = paymentResult.rows[0];

      if (!payment) {
        // An event for a PaymentIntent we have no record of. Could be a
        // stale/foreign event, a bug, or an intent created outside this
        // flow — never mark ANY booking paid from an untracked intent.
        console.error(`[payments] Webhook for unknown PaymentIntent ${intent.id} — no matching payment record, ignoring.`);
        return res.json({ received: true });
      }

      if (payment.status === 'succeeded') {
        // Already processed (Stripe redelivered the same event, or a
        // near-simultaneous duplicate arrived) — no-op, not an error.
        return res.json({ received: true });
      }

      if (intent.amount !== payment.amount_cents) {
        console.error(`[payments] Webhook amount mismatch for PaymentIntent ${intent.id}: expected ${payment.amount_cents}, got ${intent.amount}.`);
        return res.status(400).json({ success: false, error: 'Amount mismatch.' });
      }

      if (intent.currency.toUpperCase() !== payment.currency.toUpperCase()) {
        console.error(`[payments] Webhook currency mismatch for PaymentIntent ${intent.id}: expected ${payment.currency}, got ${intent.currency}.`);
        return res.status(400).json({ success: false, error: 'Currency mismatch.' });
      }

      if (intent.status !== 'succeeded') {
        // Defensive: the event TYPE says succeeded, but trust the
        // intent's own current status too, not just the event name.
        console.error(`[payments] payment_intent.succeeded event but intent.status is "${intent.status}" for ${intent.id} — not marking paid.`);
        return res.json({ received: true });
      }

      await withTransaction(async (client) => {
        await client.query(`UPDATE payments SET status = 'succeeded' WHERE id = $1`, [payment.id]);
        await client.query(`UPDATE bookings SET payment_status = 'paid', status = 'confirmed' WHERE id = $1`, [payment.booking_id]);
      });
    } else if (event.type === 'payment_intent.payment_failed') {
      const intent = event.data.object;

      const paymentResult = await query(
        `SELECT id, status FROM payments WHERE provider = 'stripe' AND provider_payment_id = $1`,
        [intent.id]
      );
      const payment = paymentResult.rows[0];

      if (!payment) {
        return res.json({ received: true });
      }
      if (payment.status === 'succeeded') {
        // A late/out-of-order failed event must never downgrade a
        // booking that a succeeded event already confirmed.
        return res.json({ received: true });
      }

      // Only the payment record changes here — the booking itself stays
      // as it was (still pending), never incorrectly marked confirmed.
      await query(`UPDATE payments SET status = 'failed' WHERE id = $1`, [payment.id]);
    }
    res.json({ received: true });
  } catch (err) {
    console.error('Webhook processing error:', err);
    // Still return an error status (not 200) so Stripe retries delivery —
    // a processing failure here should not be silently acknowledged.
    res.status(500).json({ success: false, error: 'Webhook processing failed.' });
  }
});

module.exports = router;
