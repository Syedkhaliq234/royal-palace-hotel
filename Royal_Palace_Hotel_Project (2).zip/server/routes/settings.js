const express = require('express');
const { query } = require('../db');
const { requireRole } = require('../middleware/auth');
const { requireCsrfToken } = require('../middleware/csrf');

const router = express.Router();

// Public — the website reads hotel name/address/phone/policies from here
// instead of hard-coding them in HTML, so the client can update them from
// the admin dashboard without touching code.
router.get('/settings', async (req, res) => {
  try {
    const result = await query('SELECT * FROM hotel_settings WHERE id = 1');
    res.json({ success: true, settings: result.rows[0] });
  } catch (err) {
    console.error('Get settings error:', err);
    res.status(500).json({ success: false, error: 'Could not retrieve settings.' });
  }
});

router.patch('/settings', requireRole('admin'), requireCsrfToken, async (req, res) => {
  const allowedFields = ['hotel_name', 'address', 'phone', 'email', 'currency', 'timezone'];
  const b = req.body || {};
  const setClauses = [];
  const params = [];

  for (const field of allowedFields) {
    if (b[field] !== undefined) {
      params.push(b[field]);
      setClauses.push(`${field} = $${params.length}`);
    }
  }
  if (b.policies !== undefined) {
    params.push(JSON.stringify(b.policies));
    setClauses.push(`policies = $${params.length}`);
  }
  if (b.social_links !== undefined) {
    params.push(JSON.stringify(b.social_links));
    setClauses.push(`social_links = $${params.length}`);
  }
  if (setClauses.length === 0) {
    return res.status(400).json({ success: false, error: 'No valid fields to update.' });
  }

  try {
    await query(`UPDATE hotel_settings SET ${setClauses.join(', ')} WHERE id = 1`, params);
    res.json({ success: true });
  } catch (err) {
    console.error('Update settings error:', err);
    res.status(500).json({ success: false, error: 'Could not update settings.' });
  }
});

module.exports = router;
