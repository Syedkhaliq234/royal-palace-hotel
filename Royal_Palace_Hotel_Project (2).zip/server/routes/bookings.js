const express = require('express');
const crypto = require('crypto');
const rateLimit = require('express-rate-limit');
const { query, withTransaction } = require('../db');
const { requireRole } = require('../middleware/auth');
const { requireCsrfToken } = require('../middleware/csrf');
const {
  isValidEmail,
  sanitizeEmail,
  isValidPhone,
  validateStayDates,
  generateBookingReference,
} = require('../lib/validators');
const { calculateBookingTotal } = require('../lib/pricing');
const { countOverlappingBookings, evaluateAvailability } = require('../lib/availability');
const { generatePaymentToken, hashPaymentToken, verifyPaymentToken } = require('../lib/tokens');

const router = express.Router();

const bookingLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 20,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, error: 'Too many booking attempts. Please try again later.' },
});

// Generous enough for legitimate polling (e.g. every 2-3s for up to a
// minute after a payment attempt) while still bounding abuse.
const statusCheckLimiter = rateLimit({
  windowMs: 5 * 60 * 1000,
  max: 60,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, error: 'Too many requests. Please try again later.' },
});

/**
 * POST /api/bookings/status
 * Body: { booking_reference, payment_token }
 *
 * Public, but authorized the same way as POST /api/payments/create (the
 * booking_reference + payment_token pair — see lib/tokens.js for why this
 * is a real capability token, not a guessable ID). Lets the frontend poll
 * for the ACTUAL, webhook-confirmed payment_status after Stripe.js
 * reports a client-side result — Stripe.js succeeding is not, by itself,
 * proof that our database reflects it yet. This is the only source the
 * frontend should trust for "is this booking really paid."
 *
 * Intentionally POST, not GET: payment_token is a sensitive bearer
 * capability, and GET query strings routinely end up in server access
 * logs, browser history, and Referer headers sent to third parties — a
 * POST body does not. (The route itself is still read-only/idempotent;
 * POST is used here purely to keep the token out of the URL, not because
 * this creates or mutates anything.)
 */
router.post('/bookings/status', statusCheckLimiter, async (req, res) => {
  const bookingReference = (req.body && req.body.booking_reference || '').toString().trim();
  const paymentToken = (req.body && req.body.payment_token || '').toString().trim();

  if (!bookingReference || !paymentToken) {
    return res.status(400).json({ success: false, error: 'booking_reference and payment_token are required.' });
  }

  try {
    const result = await query(
      `SELECT booking_reference, status, payment_status, payment_token_hash
       FROM bookings WHERE booking_reference = $1`,
      [bookingReference]
    );
    const booking = result.rows[0];

    if (!booking || !verifyPaymentToken(paymentToken, booking.payment_token_hash)) {
      return res.status(404).json({ success: false, error: 'Booking not found.' });
    }

    res.json({
      success: true,
      status: booking.status,
      paymentStatus: booking.payment_status,
    });
  } catch (err) {
    console.error('Booking status check error:', err);
    res.status(500).json({ success: false, error: 'Could not check booking status.' });
  }
});

/**
 * GET /api/availability?room_id=...&check_in=YYYY-MM-DD&check_out=YYYY-MM-DD
 * Public. Read-only — safe to call without a transaction/lock since it's
 * advisory only (the real guarantee happens at booking-creation time).
 */
router.get('/availability', async (req, res) => {
  const { room_id, check_in, check_out } = req.query;

  const dateCheck = validateStayDates(check_in, check_out);
  if (!dateCheck.valid) {
    return res.status(400).json({ success: false, error: dateCheck.error });
  }
  if (!room_id) {
    return res.status(400).json({ success: false, error: 'room_id is required.' });
  }

  try {
    const roomResult = await query('SELECT id, total_units FROM rooms WHERE id = $1 AND status = $2', [room_id, 'active']);
    const room = roomResult.rows[0];
    if (!room) {
      return res.status(404).json({ success: false, error: 'Room not found.' });
    }

    const overlapResult = await query(
      `SELECT check_in, check_out FROM bookings
       WHERE room_id = $1 AND status IN ('pending', 'confirmed')
         AND check_in < $3 AND $2 < check_out`,
      [room_id, check_in, check_out]
    );

    const overlappingCount = countOverlappingBookings(
      overlapResult.rows.map((r) => ({ check_in: r.check_in, check_out: r.check_out })),
      check_in,
      check_out
    );
    const { available, remainingUnits } = evaluateAvailability(room.total_units, overlappingCount);

    res.json({ success: true, available, remainingUnits, nights: dateCheck.nights });
  } catch (err) {
    console.error('Availability check error:', err);
    res.status(500).json({ success: false, error: 'Could not check availability.' });
  }
});

/**
 * POST /api/bookings
 * Public. Creates a booking with a SERVER-SIDE double-booking guarantee.
 *
 * How the guarantee works (read carefully — this is the critical part):
 *   1. Everything happens inside a single database transaction.
 *   2. `SELECT ... FOR UPDATE` locks the matching booking rows (and, for the
 *      first booking of a room with none yet, the room row itself via a
 *      separate row lock) so that a SECOND concurrent request for the same
 *      room/overlapping dates has to wait for the first transaction to
 *      commit or roll back before it can even read the current count.
 *   3. After acquiring the lock, we recount overlapping bookings and check
 *      against total_units. Only if a unit is free do we INSERT.
 *   4. COMMIT releases the lock; the next waiting transaction then sees the
 *      updated count and correctly detects "no longer available" if that
 *      was the last unit.
 *
 * This is the standard, correct pattern for preventing race conditions in
 * Postgres without a separate inventory-per-unit table. It has NOT been
 * tested against a live database in this environment (no DB access here) —
 * the logic is standard and well-documented, but genuinely concurrent
 * behavior can only be verified by running two real simultaneous requests
 * against a real Postgres instance, which requires deployment.
 */
router.post('/bookings', bookingLimiter, async (req, res) => {
  const body = req.body || {};
  const fullName = (body.full_name || '').trim();
  const email = sanitizeEmail(body.email);
  const phone = (body.phone || '').trim();
  const roomId = body.room_id;
  const checkIn = body.check_in;
  const checkOut = body.check_out;
  const guests = parseInt(body.guests, 10);
  const specialRequests = (body.special_requests || '').trim().slice(0, 2000);

  // --- Validation (never trust the client) ---
  if (!fullName) return res.status(400).json({ success: false, error: 'Full name is required.' });
  if (!isValidEmail(email)) return res.status(400).json({ success: false, error: 'A valid email is required.' });
  if (!isValidPhone(phone)) return res.status(400).json({ success: false, error: 'Please provide a valid phone number.' });
  if (!roomId) return res.status(400).json({ success: false, error: 'room_id is required.' });
  if (!Number.isInteger(guests) || guests <= 0) return res.status(400).json({ success: false, error: 'Guest count must be a positive number.' });

  const dateCheck = validateStayDates(checkIn, checkOut);
  if (!dateCheck.valid) return res.status(400).json({ success: false, error: dateCheck.error });

  try {
    const result = await withTransaction(async (client) => {
      // Lock the room row itself first — this serializes ALL booking
      // attempts for this room, which is simple and safe (if a bit
      // more contended than per-date locking would be; acceptable for
      // a single hotel's booking volume).
      const roomResult = await client.query(
        'SELECT id, price_cents, currency, capacity, total_units FROM rooms WHERE id = $1 AND status = $2 FOR UPDATE',
        [roomId, 'active']
      );
      const room = roomResult.rows[0];
      if (!room) {
        const err = new Error('Room not found or not available.');
        err.statusCode = 404;
        throw err;
      }

      if (guests > room.capacity) {
        const err = new Error(`This room accommodates up to ${room.capacity} guests.`);
        err.statusCode = 400;
        throw err;
      }

      const overlapResult = await client.query(
        `SELECT check_in, check_out FROM bookings
         WHERE room_id = $1 AND status IN ('pending', 'confirmed')
           AND check_in < $3 AND $2 < check_out`,
        [roomId, checkIn, checkOut]
      );
      const overlappingCount = countOverlappingBookings(
        overlapResult.rows.map((r) => ({ check_in: r.check_in, check_out: r.check_out })),
        checkIn,
        checkOut
      );
      const { available } = evaluateAvailability(room.total_units, overlappingCount);

      if (!available) {
        const err = new Error('This room is no longer available for the selected dates.');
        err.statusCode = 409;
        throw err;
      }

      // Upsert customer by email
      const customerResult = await client.query(
        `INSERT INTO customers (name, email, phone)
         VALUES ($1, $2, $3)
         ON CONFLICT (email) DO UPDATE SET name = EXCLUDED.name, phone = EXCLUDED.phone
         RETURNING id`,
        [fullName, email, phone || null]
      );
      const customerId = customerResult.rows[0].id;

      const pricing = calculateBookingTotal(room.price_cents, dateCheck.nights);
      const bookingReference = generateBookingReference(crypto.randomBytes(6));

      // Generated fresh per booking. The raw token is returned to the
      // client exactly once, in this response — never stored, logged, or
      // retrievable again afterward. Losing it means the guest (or the
      // frontend, if payment isn't collected immediately) must go through
      // hotel staff / the admin dashboard to complete payment instead.
      const rawPaymentToken = generatePaymentToken();
      const paymentTokenHash = hashPaymentToken(rawPaymentToken);

      const bookingResult = await client.query(
        `INSERT INTO bookings
           (booking_reference, customer_id, room_id, check_in, check_out, guests, special_requests, total_amount_cents, currency, status, payment_status, payment_token_hash)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, 'pending', 'pending', $10)
         RETURNING id, booking_reference, check_in, check_out, total_amount_cents, currency, status`,
        [bookingReference, customerId, roomId, checkIn, checkOut, guests, specialRequests || null, pricing.totalCents, room.currency, paymentTokenHash]
      );

      return { ...bookingResult.rows[0], rawPaymentToken };
    });

    // Email confirmation: only send if a real provider is configured.
    // See server/lib/email.js — never fake this.
    const { sendBookingConfirmationEmail } = require('../lib/email');
    sendBookingConfirmationEmail(email, result).catch((e) => console.error('Booking email error:', e));

    res.status(201).json({
      success: true,
      booking: {
        reference: result.booking_reference,
        checkIn: result.check_in,
        checkOut: result.check_out,
        totalCents: result.total_amount_cents,
        currency: result.currency,
        status: result.status,
        paymentToken: result.rawPaymentToken, // required by POST /api/payments/create — shown/stored client-side ONLY, never logged server-side
      },
    });
  } catch (err) {
    const statusCode = err.statusCode || 500;
    if (statusCode === 500) console.error('Booking creation error:', err);
    res.status(statusCode).json({ success: false, error: err.message || 'Could not create booking.' });
  }
});

/**
 * GET /api/bookings — admin only, list/search/filter
 */
router.get('/bookings', requireRole('admin', 'manager', 'staff'), async (req, res) => {
  try {
    const status = req.query.status;
    const search = (req.query.search || '').trim();

    let sql = `
      SELECT b.id, b.booking_reference, b.check_in, b.check_out, b.guests, b.total_amount_cents,
             b.currency, b.status, b.payment_status, b.created_at,
             c.name AS customer_name, c.email AS customer_email, c.phone AS customer_phone,
             r.name AS room_name
      FROM bookings b
      JOIN customers c ON c.id = b.customer_id
      JOIN rooms r ON r.id = b.room_id
      WHERE 1=1
    `;
    const params = [];

    if (status) {
      params.push(status);
      sql += ` AND b.status = $${params.length}`;
    }
    if (search) {
      params.push(`%${search.toLowerCase()}%`);
      sql += ` AND (LOWER(c.name) LIKE $${params.length} OR LOWER(c.email) LIKE $${params.length} OR LOWER(b.booking_reference) LIKE $${params.length})`;
    }
    sql += ' ORDER BY b.created_at DESC LIMIT 200';

    const result = await query(sql, params);
    res.json({ success: true, bookings: result.rows });
  } catch (err) {
    console.error('List bookings error:', err);
    res.status(500).json({ success: false, error: 'Could not retrieve bookings.' });
  }
});

/**
 * PATCH /api/bookings/:id — admin only, update status
 */
router.patch('/bookings/:id', requireRole('admin', 'manager'), requireCsrfToken, async (req, res) => {
  const { status } = req.body || {};
  const allowedStatuses = ['pending', 'confirmed', 'cancelled', 'completed', 'no_show'];
  if (!allowedStatuses.includes(status)) {
    return res.status(400).json({ success: false, error: 'Invalid status value.' });
  }
  try {
    const result = await query('UPDATE bookings SET status = $1 WHERE id = $2 RETURNING id', [status, req.params.id]);
    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, error: 'Booking not found.' });
    }
    res.json({ success: true });
  } catch (err) {
    console.error('Update booking error:', err);
    res.status(500).json({ success: false, error: 'Could not update booking.' });
  }
});

/**
 * POST /api/bookings/:id/cancel — admin only (guest-initiated cancellation
 * would need a separate, token-authenticated public route — not implemented
 * here; out of scope until a real guest-account or magic-link system exists).
 */
router.post('/bookings/:id/cancel', requireRole('admin', 'manager'), requireCsrfToken, async (req, res) => {
  try {
    const result = await query(
      `UPDATE bookings SET status = 'cancelled' WHERE id = $1 AND status != 'cancelled' RETURNING id`,
      [req.params.id]
    );
    if (result.rows.length === 0) {
      return res.status(404).json({ success: false, error: 'Booking not found or already cancelled.' });
    }
    res.json({ success: true });
  } catch (err) {
    console.error('Cancel booking error:', err);
    res.status(500).json({ success: false, error: 'Could not cancel booking.' });
  }
});

module.exports = router;
