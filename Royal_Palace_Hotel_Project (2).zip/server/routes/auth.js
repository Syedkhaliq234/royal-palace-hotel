const express = require('express');
const bcrypt = require('bcrypt');
const rateLimit = require('express-rate-limit');
const { query } = require('../db');
const { generateCsrfToken } = require('../middleware/csrf');

const router = express.Router();

// Deliberately strict — login endpoints are a common brute-force target.
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 8,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, error: 'Too many login attempts. Please try again later.' },
});

router.get('/csrf-token', generateCsrfToken);

router.post('/login', loginLimiter, async (req, res) => {
  const email = (req.body && req.body.email || '').trim().toLowerCase();
  const password = req.body && req.body.password;

  if (!email || !password) {
    return res.status(400).json({ success: false, error: 'Email and password are required.' });
  }

  try {
    const result = await query('SELECT id, name, email, password_hash, role FROM users WHERE email = $1', [email]);
    const user = result.rows[0];

    // Always run bcrypt.compare even if the user doesn't exist, using a
    // dummy hash, so response timing doesn't reveal whether the email
    // exists (a real, if minor, information-leak in naive implementations).
    const hashToCompare = user ? user.password_hash : '$2b$12$invalidsaltinvalidsaltinvalidsaltinvalidsalu';
    const passwordMatches = await bcrypt.compare(password, hashToCompare);

    if (!user || !passwordMatches) {
      return res.status(401).json({ success: false, error: 'Invalid email or password.' });
    }

    req.session.regenerate((err) => {
      if (err) {
        console.error('Session regenerate error:', err);
        return res.status(500).json({ success: false, error: 'Login failed. Please try again.' });
      }
      req.session.userId = user.id;
      req.session.role = user.role;
      req.session.name = user.name;

      query('UPDATE users SET last_login = now() WHERE id = $1', [user.id]).catch((e) =>
        console.error('Failed to update last_login:', e)
      );

      res.json({
        success: true,
        user: { id: user.id, name: user.name, email: user.email, role: user.role },
      });
    });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ success: false, error: 'Login failed. Please try again.' });
  }
});

router.post('/logout', (req, res) => {
  if (!req.session) return res.json({ success: true });
  req.session.destroy((err) => {
    if (err) {
      console.error('Logout error:', err);
      return res.status(500).json({ success: false, error: 'Logout failed.' });
    }
    res.clearCookie('connect.sid');
    res.json({ success: true });
  });
});

router.get('/me', (req, res) => {
  if (!req.session || !req.session.userId) {
    return res.status(401).json({ success: false, error: 'Not authenticated.' });
  }
  res.json({
    success: true,
    user: { id: req.session.userId, name: req.session.name, role: req.session.role },
  });
});

module.exports = router;
