const express = require('express');
const { query } = require('../db');
const { requireRole } = require('../middleware/auth');

const router = express.Router();

router.get('/customers', requireRole('admin', 'manager', 'staff'), async (req, res) => {
  const search = (req.query.search || '').trim().toLowerCase();
  try {
    let sql = 'SELECT id, name, email, phone, country, created_at FROM customers';
    const params = [];
    if (search) {
      params.push(`%${search}%`);
      sql += ' WHERE LOWER(name) LIKE $1 OR LOWER(email) LIKE $1';
    }
    sql += ' ORDER BY created_at DESC LIMIT 200';
    const result = await query(sql, params);
    res.json({ success: true, customers: result.rows });
  } catch (err) {
    console.error('List customers error:', err);
    res.status(500).json({ success: false, error: 'Could not retrieve customers.' });
  }
});

router.get('/customers/:id/bookings', requireRole('admin', 'manager', 'staff'), async (req, res) => {
  try {
    const result = await query(
      `SELECT b.id, b.booking_reference, b.check_in, b.check_out, b.status, b.payment_status, b.total_amount_cents, b.currency, r.name AS room_name
       FROM bookings b JOIN rooms r ON r.id = b.room_id
       WHERE b.customer_id = $1 ORDER BY b.created_at DESC`,
      [req.params.id]
    );
    res.json({ success: true, bookings: result.rows });
  } catch (err) {
    console.error('Customer booking history error:', err);
    res.status(500).json({ success: false, error: 'Could not retrieve booking history.' });
  }
});

module.exports = router;
