const express = require('express');
const crypto = require('crypto');
const rateLimit = require('express-rate-limit');
const { query } = require('../db');
const { requireRole } = require('../middleware/auth');
const { requireCsrfToken } = require('../middleware/csrf');
const { isValidEmail, sanitizeEmail, escapeCsvField } = require('../lib/validators');

const router = express.Router();

const subscribeLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, error: 'Too many requests. Please try again later.' },
});

router.post('/newsletter/subscribe', subscribeLimiter, async (req, res) => {
  const email = sanitizeEmail(req.body && req.body.email);
  if (!isValidEmail(email)) {
    return res.status(400).json({ success: false, error: 'Please provide a valid email address.' });
  }

  try {
    const existing = await query('SELECT id, status FROM subscribers WHERE email = $1', [email]);
    if (existing.rows.length > 0) {
      const sub = existing.rows[0];
      if (sub.status === 'unsubscribed') {
        await query(`UPDATE subscribers SET status = 'active', subscribed_at = now() WHERE id = $1`, [sub.id]);
        return res.json({ success: true, message: 'Welcome back! You have been resubscribed.' });
      }
      return res.status(409).json({ success: false, error: 'This email is already subscribed.' });
    }

    await query('INSERT INTO subscribers (email, status) VALUES ($1, $2)', [email, 'active']);
    res.status(201).json({ success: true, message: 'Thank you for subscribing!' });
  } catch (err) {
    console.error('Subscribe error:', err);
    res.status(500).json({ success: false, error: 'Something went wrong. Please try again later.' });
  }
});

router.get('/newsletter/subscribers', requireRole('admin', 'manager'), async (req, res) => {
  const search = (req.query.search || '').trim().toLowerCase();
  try {
    let sql = 'SELECT id, email, status, subscribed_at FROM subscribers';
    const params = [];
    if (search) {
      params.push(`%${search}%`);
      sql += ' WHERE LOWER(email) LIKE $1';
    }
    sql += ' ORDER BY subscribed_at DESC';
    const result = await query(sql, params);
    res.json({ success: true, count: result.rows.length, subscribers: result.rows });
  } catch (err) {
    console.error('List subscribers error:', err);
    res.status(500).json({ success: false, error: 'Could not retrieve subscribers.' });
  }
});

router.get('/newsletter/subscribers/export', requireRole('admin', 'manager'), async (req, res) => {
  try {
    const result = await query('SELECT email, status, subscribed_at FROM subscribers ORDER BY subscribed_at DESC');
    const header = 'email,status,subscribed_at\n';
    const csvBody = result.rows.map((r) => [r.email, r.status, r.subscribed_at].map(escapeCsvField).join(',')).join('\n');
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="newsletter-subscribers.csv"');
    res.send(header + csvBody);
  } catch (err) {
    console.error('Export subscribers error:', err);
    res.status(500).json({ success: false, error: 'Could not export subscribers.' });
  }
});

router.delete('/newsletter/subscribers/:id', requireRole('admin', 'manager'), requireCsrfToken, async (req, res) => {
  try {
    const result = await query('DELETE FROM subscribers WHERE id = $1', [req.params.id]);
    if (result.rowCount === 0) return res.status(404).json({ success: false, error: 'Subscriber not found.' });
    res.json({ success: true });
  } catch (err) {
    console.error('Delete subscriber error:', err);
    res.status(500).json({ success: false, error: 'Could not delete subscriber.' });
  }
});

module.exports = router;
