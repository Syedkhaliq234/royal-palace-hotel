const { Pool } = require('pg');

if (!process.env.DATABASE_URL) {
  console.error('FATAL: DATABASE_URL is not set. See .env.example.');
  process.exit(1);
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  // Most managed Postgres providers (Render, Railway, Supabase, Neon)
  // require SSL. Set PGSSL=false in .env if connecting to a local DB
  // without SSL during development.
  ssl: process.env.PGSSL === 'false' ? false : { rejectUnauthorized: false },
});

pool.on('error', (err) => {
  // Handles errors from idle clients in the pool (e.g. connection dropped)
  // so a single bad connection doesn't crash the whole process.
  console.error('Unexpected error on idle database client:', err);
});

/**
 * Run a query with automatic connection handling.
 * @param {string} text
 * @param {Array} params
 */
function query(text, params) {
  return pool.query(text, params);
}

/**
 * Run a function inside a transaction. The callback receives a client
 * that MUST be used for all queries inside the transaction (not `pool`
 * directly, or they won't be part of the same transaction).
 * Automatically rolls back on error, commits on success.
 */
async function withTransaction(callback) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const result = await callback(client);
    await client.query('COMMIT');
    return result;
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

module.exports = { pool, query, withTransaction };
