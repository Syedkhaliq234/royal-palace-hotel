# Royal Palace Hotel — Backend API

Real backend: Postgres database, bcrypt-hashed admin auth with server-side
sessions, a transaction-safe booking/availability engine, and newsletter
management. **Not deployed or tested against a live database by Claude** —
no network access or hosting was available while building this. You (or a
backend developer) must deploy and test it before it does anything.

This replaces the standalone `newsletter-server/` folder from earlier —
that one is now redundant. Once this is deployed, decommission it.

## 1. Requirements

- Node.js 18+
- A PostgreSQL database (managed: Render, Railway, Supabase, or Neon all work)

## 2. Install

```bash
cd server
npm install
cp .env.example .env
```

**Note on `package-lock.json`:** this project does not ship a lockfile.
Generating a real one requires contacting the npm registry to resolve
exact versions and cryptographic integrity hashes for every dependency
— something the environment this project was built in cannot do (no
network access, confirmed via a direct `npm install` attempt returning
`403 Forbidden — Host not in allowlist`). Running `npm install` here
(with real internet access) will generate a fresh, valid
`package-lock.json` automatically from the version ranges in
`package.json` — commit it after your first install so future installs
are reproducible.

Edit `.env`:
- `DATABASE_URL` — your Postgres connection string
- `SESSION_SECRET` — generate with `openssl rand -hex 32`
- `ALLOWED_ORIGINS` — your live website domain(s), comma-separated
- `SEED_ADMIN_EMAIL` / `SEED_ADMIN_PASSWORD` — for the first admin account
  (used once by the seed script, see below)
- Leave `STRIPE_*` and `RESEND_API_KEY` blank until you have real accounts
  — the app runs fine without them, it just returns
  `PAYMENT PROVIDER CONFIGURATION REQUIRED` / skips sending email until set

## 3. Set up the database

```bash
psql "$DATABASE_URL" -f schema.sql
npm run seed:admin
```

The seed script creates your first admin login using `SEED_ADMIN_EMAIL` /
`SEED_ADMIN_PASSWORD` from `.env`. Re-run it any time to reset that
account's password. **Remove `SEED_ADMIN_PASSWORD` from `.env` after this
runs** — it's no longer needed and shouldn't sit in a config file.

## 4. Run

```bash
npm start
```

Runs on `http://localhost:3001` (or `$PORT`). Health check:

```bash
curl http://localhost:3001/api/health
```

## 5. Run the tests

```bash
npm test
```

This runs 50 unit tests covering validation, pricing math, availability-
overlap logic, payment-authorization tokens, XSS-escaping behavior, and
route-structure regression checks — using Node's built-in test runner, no
extra install needed. These test pure logic only; they do NOT test
against a real database (that requires a live Postgres instance and
hasn't been done yet — see "What hasn't been tested" below).

## 6. Deploy

Any Node host with Postgres access works: Render, Railway, Fly.io, a VPS.
Set all `.env` values as environment variables in your host's dashboard —
never commit `.env`. Set `NODE_ENV=production` (most hosts do this
automatically) so secure cookies and error responses behave correctly.

Run the schema + seed script once against your production database the
same way as step 3, using your production `DATABASE_URL`.

## 7. Connect the frontend

Edit **`config.js`** (in the project root, alongside `index.html` and
`admin.html`) — this is the single file both pages load their API URL
and Stripe publishable key from:

```js
window.HOTEL_API_BASE_URL = "https://api.royalpalacehotel.com"; // <-- your deployed API
window.STRIPE_PUBLISHABLE_KEY = "pk_test_..."; // <-- from your Stripe dashboard, safe to expose
```

The frontend must also fetch a CSRF token (`GET /api/auth/csrf-token`)
before any admin POST/PATCH/DELETE request and send it back as an
`X-CSRF-Token` header — see the inline comments in `middleware/csrf.js`.
`index.html`'s guest checkout flow does this itself automatically before
calling `/api/payments/create` (see the `gaShowPostBookingState` function).

**Frontend payment flow (implemented in `index.html`):** after a booking
is created, if `STRIPE_PUBLISHABLE_KEY` is set, the page automatically
calls `/api/payments/create` with the booking's `booking_reference` +
`paymentToken`, loads Stripe.js, and mounts a Stripe Payment Element for
card entry. Payment confirmation happens via Stripe.js
(`stripe.confirmPayment`) — the frontend never marks a booking as paid
itself; only the webhook (`POST /api/payments/webhook`) updates
`payment_status` in the database. If `STRIPE_PUBLISHABLE_KEY` is not set,
the booking still succeeds and the guest sees an honest
"online payment is currently unavailable" message instead.

**Payment confirmation is never claimed from Stripe.js alone.** When
`stripe.confirmPayment` reports `succeeded`, the UI shows "Payment
submitted successfully... being securely verified" — not "confirmed" —
and polls the `POST /api/bookings/status` endpoint (authorized the
same way as payment creation: `booking_reference` + `payment_token`,
never a guessable ID) every few seconds for up to ~60 seconds. Only once
that endpoint reports `payment_status === 'paid'` — meaning the webhook
has actually run and the database reflects it — does the UI say "Payment
confirmed." If polling times out, the guest is told verification is
taking longer than usual and to expect a confirmation email, rather than
either falsely claiming success or leaving them on an infinite spinner.

**Frontend availability check (implemented in `index.html`):** once a
room, check-in, and check-out are all selected, the page calls
`GET /api/availability` and shows an inline available/unavailable message.
This is a UX convenience only — the booking transaction's own
transaction-locked availability check remains the actual authority, and
still runs even if this frontend check said "available."

## What is implemented

- Real Postgres schema with foreign keys, constraints, indexes
- bcrypt password hashing, session-based auth (httpOnly, secure cookies),
  role-based access (admin/manager/staff), login rate limiting
- CSRF protection on all state-changing admin routes
- Booking creation inside a database transaction with row-level locking to
  prevent double-booking (see detailed comments in `routes/bookings.js`)
- Server-side price calculation (frontend price is never trusted)
- Newsletter subscribe/list/search/delete/export, migrated to Postgres
- Global JSON error handler — never leaks stack traces
- Stripe and email (Resend) integration points that honestly report
  "not configured" instead of faking success
- Duplicate-payment prevention: booking row locking + existing-payment
  reuse + Stripe idempotency keys, so a double-click or retried request
  cannot create two PaymentIntents for the same booking (see detailed
  comments in `routes/payments.js`)
- Webhook validation chain: an incoming `payment_intent.succeeded` event
  only marks a booking paid after confirming a matching payment record
  exists, it isn't already processed, the amount matches, the currency
  matches, and the PaymentIntent's own status genuinely says succeeded

## What has NOT been tested (be honest with your client about this)

- **Never run against a live database.** No Postgres was available in the
  environment this was built in (no local install, no network to reach a
  managed one). Schema syntax was reviewed manually, not executed.
- **Never started as a running server.** `npm install` could not complete
  in that environment either (no network). Every file passed
  `node --check` (syntax validation) and the 23 pure-logic unit tests
  actually ran and passed, but that is not the same as a live integration
  test.
- **Concurrent double-booking prevention** is standard, well-documented
  Postgres locking technique, but "does it actually stop two simultaneous
  requests" can only be proven by firing two real concurrent requests at a
  real running server — this has not been done.
- **Stripe and Resend integrations are real, complete code — not
  commented-out scaffolding — but untested against live accounts.** Run
  `npm install` (stripe is an optional dependency, only needed once you
  have real keys), add real credentials to `.env`, and test with
  sandbox/test-mode credentials before going live. `POST /api/payments/create`
  requires `{ booking_reference, payment_token }` — `payment_token` is a
  256-bit secret returned exactly once in the `POST /api/bookings`
  response (`booking.paymentToken`) and never stored in plaintext or
  logged; it's the actual authorization control, not `booking_id` or
  `booking_reference` (neither of which is secret enough on its own). See
  the detailed comment in `routes/payments.js` and `lib/tokens.js`.

## Backup & recovery

- Most managed Postgres providers (Render, Railway, Supabase, Neon) offer
  automatic daily backups — enable this in your provider's dashboard.
- Manual backup: `pg_dump "$DATABASE_URL" > backup.sql`
- Restore: `psql "$DATABASE_URL" < backup.sql`
- Test your restore process before you need it for real — an untested
  backup is not a backup.

## Migrations

This project ships one `schema.sql`, not a migration framework. For a
single-hotel deployment this is usually fine. If the schema needs to
change after launch (e.g. adding a column), write and review the `ALTER
TABLE` statement by hand, test it against a copy of the production
database first, then run it during a maintenance window. Consider
adopting a proper migration tool (e.g. `node-pg-migrate`) if the schema
starts changing frequently.
