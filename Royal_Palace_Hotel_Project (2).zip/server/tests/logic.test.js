const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const { isValidEmail, validateStayDates, isValidPhone, escapeCsvField, generateBookingReference } = require('../lib/validators');
const { calculateBookingTotal } = require('../lib/pricing');
const { countOverlappingBookings, evaluateAvailability } = require('../lib/availability');
const { generatePaymentToken, hashPaymentToken, verifyPaymentToken } = require('../lib/tokens');

// ---------- validators.js ----------

test('isValidEmail accepts valid addresses', () => {
  assert.equal(isValidEmail('guest@example.com'), true);
  assert.equal(isValidEmail('  Guest@Example.COM  '), true);
});

test('isValidEmail rejects invalid addresses', () => {
  assert.equal(isValidEmail('not-an-email'), false);
  assert.equal(isValidEmail(''), false);
  assert.equal(isValidEmail(null), false);
  assert.equal(isValidEmail('a@@b.com'), false);
});

test('validateStayDates rejects past check-in', () => {
  const now = new Date('2026-08-09T12:00:00Z');
  const result = validateStayDates('2026-08-01', '2026-08-05', now);
  assert.equal(result.valid, false);
  assert.match(result.error, /past/);
});

test('validateStayDates rejects checkout before checkin', () => {
  const now = new Date('2026-08-09T12:00:00Z');
  const result = validateStayDates('2026-08-15', '2026-08-10', now);
  assert.equal(result.valid, false);
  assert.match(result.error, /after check-in/);
});

test('validateStayDates accepts a valid range and computes nights', () => {
  const now = new Date('2026-08-09T12:00:00Z');
  const result = validateStayDates('2026-08-10', '2026-08-13', now);
  assert.equal(result.valid, true);
  assert.equal(result.nights, 3);
});

test('validateStayDates rejects stays over 60 nights', () => {
  const now = new Date('2026-08-09T12:00:00Z');
  const result = validateStayDates('2026-08-10', '2026-12-01', now);
  assert.equal(result.valid, false);
});

test('isValidPhone allows empty (optional field)', () => {
  assert.equal(isValidPhone(''), true);
  assert.equal(isValidPhone(undefined), true);
});

test('isValidPhone rejects garbage input', () => {
  assert.equal(isValidPhone('not a phone number at all!!'), false);
});

test('isValidPhone accepts common formats', () => {
  assert.equal(isValidPhone('+923072925650'), true);
  assert.equal(isValidPhone('(555) 123-4567'), true);
});

test('escapeCsvField blocks formula injection', () => {
  assert.equal(escapeCsvField('=cmd|calc'), "\"'=cmd|calc\"");
  assert.equal(escapeCsvField('+1234'), "\"'+1234\"");
  assert.equal(escapeCsvField('normal@email.com'), '"normal@email.com"');
});

test('escapeCsvField escapes embedded quotes', () => {
  assert.equal(escapeCsvField('has"quote'), '"has""quote"');
});

test('generateBookingReference produces expected format', () => {
  const bytes = Buffer.from([1, 2, 3, 4, 5, 6]);
  const ref = generateBookingReference(bytes);
  assert.match(ref, /^RPH-[A-Z2-9]{6}$/);
});

// ---------- pricing.js ----------

test('calculateBookingTotal computes a simple total with no tax/fees', () => {
  const result = calculateBookingTotal(35000, 3); // $350.00/night x 3 nights
  assert.equal(result.subtotalCents, 105000);
  assert.equal(result.totalCents, 105000);
  assert.equal(result.nights, 3);
});

test('calculateBookingTotal applies tax correctly', () => {
  const result = calculateBookingTotal(10000, 2, { taxRatePercent: 5 }); // $100 x 2 nights, 5% tax
  assert.equal(result.subtotalCents, 20000);
  assert.equal(result.taxCents, 1000);
  assert.equal(result.totalCents, 21000);
});

test('calculateBookingTotal applies discount and fees, never goes negative', () => {
  const result = calculateBookingTotal(5000, 1, { discountCents: 100000, feesCents: 500 });
  assert.equal(result.totalCents, 0); // discount larger than subtotal+fees, clamped to 0
});

test('calculateBookingTotal rejects invalid inputs', () => {
  assert.throws(() => calculateBookingTotal(-100, 1));
  assert.throws(() => calculateBookingTotal(100, 0));
  assert.throws(() => calculateBookingTotal(100.5, 1));
});

// ---------- availability.js ----------

test('countOverlappingBookings detects a direct overlap', () => {
  const existing = [{ check_in: '2026-08-10', check_out: '2026-08-15' }];
  const count = countOverlappingBookings(existing, '2026-08-12', '2026-08-14');
  assert.equal(count, 1);
});

test('countOverlappingBookings allows back-to-back stays (checkout day == checkin day)', () => {
  const existing = [{ check_in: '2026-08-10', check_out: '2026-08-15' }];
  const count = countOverlappingBookings(existing, '2026-08-15', '2026-08-18');
  assert.equal(count, 0);
});

test('countOverlappingBookings ignores non-overlapping bookings', () => {
  const existing = [
    { check_in: '2026-08-01', check_out: '2026-08-05' },
    { check_in: '2026-09-01', check_out: '2026-09-05' },
  ];
  const count = countOverlappingBookings(existing, '2026-08-10', '2026-08-12');
  assert.equal(count, 0);
});

test('countOverlappingBookings counts multiple simultaneous overlaps', () => {
  const existing = [
    { check_in: '2026-08-10', check_out: '2026-08-20' },
    { check_in: '2026-08-12', check_out: '2026-08-14' },
    { check_in: '2026-08-01', check_out: '2026-08-05' }, // no overlap
  ];
  const count = countOverlappingBookings(existing, '2026-08-13', '2026-08-16');
  assert.equal(count, 2);
});

test('evaluateAvailability reports available when units remain', () => {
  const result = evaluateAvailability(5, 3);
  assert.equal(result.available, true);
  assert.equal(result.remainingUnits, 2);
});

test('evaluateAvailability reports unavailable when fully booked', () => {
  const result = evaluateAvailability(2, 2);
  assert.equal(result.available, false);
  assert.equal(result.remainingUnits, 0);
});

test('evaluateAvailability never goes negative if overbooked (defensive)', () => {
  const result = evaluateAvailability(2, 5);
  assert.equal(result.available, false);
  assert.equal(result.remainingUnits, 0);
});

// ---------- tokens.js (payment authorization) ----------

test('generatePaymentToken produces a 256-bit (64 hex char) token', () => {
  const token = generatePaymentToken();
  assert.equal(token.length, 64);
  assert.match(token, /^[0-9a-f]{64}$/);
});

test('generatePaymentToken produces unique tokens', () => {
  const a = generatePaymentToken();
  const b = generatePaymentToken();
  assert.notEqual(a, b);
});

test('verifyPaymentToken accepts the correct token', () => {
  const token = generatePaymentToken();
  const hash = hashPaymentToken(token);
  assert.equal(verifyPaymentToken(token, hash), true);
});

test('verifyPaymentToken rejects a different valid-looking token', () => {
  const realToken = generatePaymentToken();
  const attackerToken = generatePaymentToken();
  const hash = hashPaymentToken(realToken);
  assert.equal(verifyPaymentToken(attackerToken, hash), false);
});

test('verifyPaymentToken rejects empty/missing input without throwing', () => {
  const hash = hashPaymentToken(generatePaymentToken());
  assert.equal(verifyPaymentToken('', hash), false);
  assert.equal(verifyPaymentToken(null, hash), false);
  assert.equal(verifyPaymentToken(undefined, hash), false);
  assert.equal(verifyPaymentToken('short', hash), false);
  assert.equal(verifyPaymentToken(generatePaymentToken(), ''), false);
});

test('verifyPaymentToken does not throw on mismatched-length comparison (would crash raw crypto.timingSafeEqual)', () => {
  const hash = hashPaymentToken(generatePaymentToken());
  assert.doesNotThrow(() => verifyPaymentToken('x'.repeat(1000), hash));
});

// ---------- XSS escaping (index.html's gaEscapeHtml) ----------
//
// gaEscapeHtml in index.html uses the browser DOM
// (document.createElement('div').textContent = str; return div.innerHTML)
// which can't run in this Node test environment without a DOM
// implementation (jsdom — an npm package this sandbox cannot install, no
// network access). The tests below verify the underlying escaping
// approach — converting &, <, > to their HTML entities — against the
// same payloads used to manually verify the real browser behavior during
// development. This validates the algorithm, not the literal browser
// function; the actual DOM-based implementation is a superset of this
// (it correctly handles every case the browser's own HTML serializer
// does, not just these three characters).

function testEscapeHtml(str) {
  return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

test('escaping neutralizes an <img onerror> XSS payload', () => {
  const escaped = testEscapeHtml('<img src=x onerror=alert(1)>');
  assert.equal(/<img/i.test(escaped), false);
  assert.match(escaped, /&lt;img/);
});

test('escaping neutralizes a <script> XSS payload', () => {
  const escaped = testEscapeHtml('<script>alert(document.cookie)</script>');
  assert.equal(/<script/i.test(escaped), false);
});

test('escaping neutralizes an attribute-breakout XSS payload', () => {
  const escaped = testEscapeHtml('"><svg onload=alert(1)>');
  assert.equal(/<svg/i.test(escaped), false);
});

test('escaping leaves normal guest names unchanged in content (no false positives)', () => {
  const escaped = testEscapeHtml("O'Brien-Smith");
  assert.equal(escaped, "O'Brien-Smith");
});

// ---------- /api/bookings/status route (payment_token must never be in a URL) ----------
//
// This route needs a live database to test its actual behavior (verified
// separately via the existing verifyPaymentToken tests above, which cover
// the authorization logic it relies on). What CAN be verified without a
// database is that the route is wired up the way it needs to be for
// payment_token to never appear in a URL — these tests read the actual
// route source file and assert on its structure, so they will fail if
// someone accidentally reverts this to a GET route with query params.

const bookingsRouteSource = fs.readFileSync(path.join(__dirname, '..', 'routes', 'bookings.js'), 'utf8');

test('bookings/status route is registered as POST, not GET', () => {
  assert.match(bookingsRouteSource, /router\.post\('\/bookings\/status'/);
  assert.doesNotMatch(bookingsRouteSource, /router\.get\('\/bookings\/status'/);
});

test('bookings/status route reads payment_token from req.body, not req.query', () => {
  // Find just the /bookings/status handler, not the whole file, so this
  // doesn't false-positive on other routes that do use req.query.
  const handlerStart = bookingsRouteSource.indexOf("router.post('/bookings/status'");
  const handlerEnd = bookingsRouteSource.indexOf('\n});', handlerStart);
  const handlerSource = bookingsRouteSource.slice(handlerStart, handlerEnd);

  assert.match(handlerSource, /req\.body/);
  assert.doesNotMatch(handlerSource, /req\.query\.payment_token/);
});

test('frontend polling code sends payment_token in a JSON body, not a URL query string', () => {
  const indexHtmlSource = fs.readFileSync(path.join(__dirname, '..', '..', 'index.html'), 'utf8');
  const pollFnStart = indexHtmlSource.indexOf('function gaPollBookingStatus');
  const pollFnEnd = indexHtmlSource.indexOf('\n  }\n', pollFnStart);
  const pollFnSource = indexHtmlSource.slice(pollFnStart, pollFnEnd);

  assert.match(pollFnSource, /method:\s*'POST'/);
  assert.match(pollFnSource, /body:\s*JSON\.stringify/);
  assert.doesNotMatch(pollFnSource, /[?&]payment_token=/);
});

// ---------- payments.js — duplicate-payment prevention & webhook validation ----------
//
// These are source-level structural regression tests, not live behavioral
// tests — actually proving "two simultaneous requests only create one
// PaymentIntent" or "a real webhook event updates the real database
// correctly" requires a running server, a real database, and a real (or
// Stripe-test-mode) Stripe account, none of which are available in this
// environment (see README "What has NOT been tested"). What these CAN
// honestly verify: that the specific safeguards this fix adds are present
// in the code and haven't been accidentally removed by a future edit —
// each test targets one specific requirement from the fix.

const paymentsRouteSource = fs.readFileSync(path.join(__dirname, '..', 'routes', 'payments.js'), 'utf8');
const createHandlerStart = paymentsRouteSource.indexOf("router.post('/payments/create'");
const createHandlerEnd = paymentsRouteSource.indexOf("\n/**\n * POST /api/payments/webhook", createHandlerStart);
const createHandlerSource = paymentsRouteSource.slice(createHandlerStart, createHandlerEnd);

const webhookHandlerStart = paymentsRouteSource.indexOf("router.post('/payments/webhook'");
const webhookHandlerSource = paymentsRouteSource.slice(webhookHandlerStart);

test('payment creation locks the booking row before checking for existing payments (prevents the race)', () => {
  assert.match(createHandlerSource, /FOR UPDATE/);
});

test('payment creation checks for an existing payment before creating a new PaymentIntent', () => {
  assert.match(createHandlerSource, /SELECT id, provider_payment_id, status FROM payments/);
  assert.match(createHandlerSource, /WHERE booking_id = \$1 AND provider = 'stripe'/);
});

test('payment creation reuses an existing PaymentIntent when Stripe confirms it is still usable', () => {
  assert.match(createHandlerSource, /stripe\.paymentIntents\.retrieve/);
  assert.match(createHandlerSource, /REUSABLE_INTENT_STATUSES/);
});

test('payment creation rejects reuse of an already-succeeded PaymentIntent as "already paid", not a fresh charge', () => {
  assert.match(createHandlerSource, /remoteIntent\.status === 'succeeded'/);
});

test('payment creation passes a deterministic Stripe idempotency key derived from the booking', () => {
  assert.match(createHandlerSource, /idempotencyKey:\s*'booking-payment-create-'\s*\+\s*booking\.id/);
});

test('payment creation blocks a booking that is already marked paid, before touching Stripe at all', () => {
  const alreadyPaidCheckIndex = createHandlerSource.indexOf("booking.payment_status === 'paid'");
  const stripeCreateIndex = createHandlerSource.indexOf('stripe.paymentIntents.create');
  assert.ok(alreadyPaidCheckIndex !== -1, 'already-paid check should exist');
  assert.ok(alreadyPaidCheckIndex < stripeCreateIndex, 'already-paid check must happen before creating a new PaymentIntent');
});

test('webhook ignores events for PaymentIntents with no matching payment record (unknown/untracked)', () => {
  assert.match(webhookHandlerSource, /if \(!payment\) {/);
  assert.match(webhookHandlerSource, /no matching payment record, ignoring/);
});

test('webhook is idempotent — an already-succeeded payment short-circuits before any UPDATE', () => {
  const succeededIdx = webhookHandlerSource.indexOf("payment.status === 'succeeded'");
  const updateIdx = webhookHandlerSource.indexOf("UPDATE payments SET status = 'succeeded'");
  assert.ok(succeededIdx !== -1, 'idempotency guard should exist');
  assert.ok(succeededIdx < updateIdx, 'idempotency guard must run before the UPDATE');
});

test('webhook validates the charged amount matches the recorded payment amount before confirming', () => {
  assert.match(webhookHandlerSource, /intent\.amount !== payment\.amount_cents/);
});

test('webhook validates the currency matches the recorded payment currency before confirming', () => {
  assert.match(webhookHandlerSource, /intent\.currency\.toUpperCase\(\) !== payment\.currency\.toUpperCase\(\)/);
});

test('webhook checks the PaymentIntent\'s own status is genuinely succeeded, not just the event type', () => {
  assert.match(webhookHandlerSource, /intent\.status !== 'succeeded'/);
});

test('webhook only marks a booking paid/confirmed after ALL validation checks, inside one transaction', () => {
  const lastCheckIndex = webhookHandlerSource.indexOf("intent.status !== 'succeeded'");
  const transactionIndex = webhookHandlerSource.indexOf('withTransaction');
  const bookingUpdateIndex = webhookHandlerSource.indexOf("UPDATE bookings SET payment_status = 'paid'");
  assert.ok(lastCheckIndex < transactionIndex, 'all validation must happen before the transaction');
  assert.ok(transactionIndex < bookingUpdateIndex, 'booking update must happen inside the transaction');
});

test('payment_intent.payment_failed only updates the payments table, never the bookings table', () => {
  const failedHandlerStart = webhookHandlerSource.indexOf("event.type === 'payment_intent.payment_failed'");
  const failedHandlerSource = webhookHandlerSource.slice(failedHandlerStart);
  assert.match(failedHandlerSource, /UPDATE payments SET status = 'failed'/);
  assert.doesNotMatch(failedHandlerSource, /UPDATE bookings/);
});

test('a late payment_intent.payment_failed event cannot downgrade an already-succeeded payment', () => {
  const failedHandlerStart = webhookHandlerSource.indexOf("event.type === 'payment_intent.payment_failed'");
  const failedHandlerSource = webhookHandlerSource.slice(failedHandlerStart);
  assert.match(failedHandlerSource, /payment\.status === 'succeeded'/);
});

