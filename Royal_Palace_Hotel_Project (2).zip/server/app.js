require('dotenv').config();
const express = require('express');
const session = require('express-session');
const pgSession = require('connect-pg-simple')(session);
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const { pool } = require('./db');

const PORT = process.env.PORT || 3001;
const SESSION_SECRET = process.env.SESSION_SECRET;
const ALLOWED_ORIGINS = (process.env.ALLOWED_ORIGINS || '').split(',').map((o) => o.trim()).filter(Boolean);
const IS_PRODUCTION = process.env.NODE_ENV === 'production';

if (!SESSION_SECRET || SESSION_SECRET.length < 32) {
  console.error('FATAL: SESSION_SECRET is not set or too short (need 32+ random characters). Generate one with: openssl rand -hex 32');
  process.exit(1);
}

const app = express();
app.set('trust proxy', 1); // required for secure cookies behind a reverse proxy (Render/Railway/etc.)

app.use(
  cors({
    origin: function (origin, callback) {
      if (!origin) return callback(null, true); // server-to-server / curl
      if (ALLOWED_ORIGINS.includes(origin)) return callback(null, true);
      return callback(new Error('Not allowed by CORS'));
    },
    credentials: true, // required so the session cookie is sent cross-origin
  })
);

// Stripe webhook needs the RAW body for signature verification, so it must
// be mounted BEFORE express.json() and use its own raw parser.
const paymentsRouter = require('./routes/payments');
app.use('/api/payments/webhook', express.raw({ type: 'application/json' }));

app.use(express.json({ limit: '20kb' }));

// Defense-in-depth: a moderate general limit on every /api route, on top
// of the stricter per-route limiters already applied to login/booking/
// newsletter. Admin routes (rooms, customers, settings, payments) had no
// rate limiting at all before this — an authenticated session being
// hammered is still a real resource-exhaustion risk worth covering.
app.use(
  '/api',
  rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 300,
    standardHeaders: true,
    legacyHeaders: false,
    message: { success: false, error: 'Too many requests. Please try again later.' },
  })
);

app.use(
  session({
    store: new pgSession({ pool, tableName: 'session' }),
    secret: SESSION_SECRET,
    name: 'connect.sid',
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      secure: IS_PRODUCTION, // requires HTTPS in production (Render/Railway provide this)
      sameSite: 'lax',
      maxAge: 1000 * 60 * 60 * 8, // 8 hours
    },
  })
);

// ---------- Routes ----------
app.get('/api/health', (req, res) => res.json({ ok: true, service: 'royal-palace-hotel-api' }));

app.use('/api/auth', require('./routes/auth'));
app.use('/api', require('./routes/rooms'));
app.use('/api', require('./routes/bookings'));
app.use('/api', require('./routes/customers'));
app.use('/api', require('./routes/newsletter'));
app.use('/api', require('./routes/settings'));
app.use('/api', paymentsRouter);

// ---------- 404 ----------
app.use((req, res) => {
  res.status(404).json({ success: false, error: 'Not found.' });
});

// ---------- Global error handler (MUST be last) ----------
// Catches CORS rejections, malformed JSON bodies, and anything thrown
// synchronously in a route. Never leaks stack traces to the client.
app.use((err, req, res, next) => {
  if (err && err.message === 'Not allowed by CORS') {
    return res.status(403).json({ success: false, error: 'Origin not allowed.' });
  }
  if (err && err.type === 'entity.parse.failed') {
    return res.status(400).json({ success: false, error: 'Malformed request body.' });
  }
  console.error('Unhandled error:', err);
  res.status(500).json({ success: false, error: 'Something went wrong. Please try again later.' });
});

app.listen(PORT, () => {
  console.log(`Royal Palace Hotel API listening on port ${PORT} (${IS_PRODUCTION ? 'production' : 'development'})`);
});

module.exports = app;
